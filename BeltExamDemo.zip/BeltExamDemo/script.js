function changeToSucculent1(elem) {
  elem.src = "assets/succulents-1.jpg";
}

function changeToSucculent2(elem) {
  elem.src = "assets/succulents-2.jpg";
}

function deleteCookie() {
  var cookie = document.querySelector("#cookie")

  cookie.remove()
}